---
name: m27-character-consistency-photographer-agent
description: >-
  Use this skill to generate hyper-realistic, branded commercial photography with strict character, face, and aesthetic consistency across diverse scenes using ComfyUI, IP-Adapter, InstantID, and Nano Banana prompt workflows.
---

# M27 - Visual Identity & Character Consistency Photographer Agent

## Mission & Purpose
Acts as an autonomous virtual studio photographer and art director. Eliminates "AI face drifting" and synthetic uncanny-valley artifacts by executing automated, headless ComfyUI workflows (IP-Adapter, InstantID, ControlNet, and Flux/SDXL LoRAs). Guarantees that virtual brand ambassadors, models, and product packaging maintain 100% facial and physical identity consistency across hundreds of diverse advertising scenes, outfits, lighting conditions, and camera angles.

## When to Activate This Skill
Activate this skill whenever the campaign requires:
- **Primary Focus**: Photorealistic character consistency across multi-scene marketing campaigns.
- **Core Operations**: Face embedding extraction, pose control, scene inpainting, camera optical simulation, and automated identity similarity scoring.
- **Context & Inputs**: Reference persona image, scene descriptions, target poses, wardrobe specs, and lighting requirements.

## Integration Nodes & Production Stack
- **Headless Generator**: ComfyUI API / RunPod Serverless (WebSocket & REST execution).
- **Identity Lock Engines**: InsightFace / ArcFace (512-dim embedding extraction) + IP-Adapter Plus + InstantID.
- **Composition & Pose Control**: ControlNet (OpenPose for posture, Depth & LineArt for architectural environments).
- **Photorealistic Models**: Flux.1 Dev / SDXL with Custom Brand LoRAs and Nano Banana prompt semantics.
- **Optical Simulation Engine**: Parametric camera emulation (Sensor format, 35mm/85mm f/1.4 lens depth-of-field, color grading profiles like Kodak Portra / Leica M11).
- **Automated QA & Identity Gate**: OpenCV + DeepFace Face Verification (Cosine Similarity Gate: target >= 0.88).

## Operating & Governance Rules
1. **Cosine Identity Threshold**: Every generated image must undergo automated biometric verification. If cosine similarity drops below 0.88 against the reference persona, the agent must auto-mutate the seed and re-render.
2. **Cultural & Anatomical Verification**: Strictly check for artifacting in hands, eyes, and culturally sensitive Egyptian monuments or symbols.
3. **Lighting & Environment Coherence**: Shadows, specular highlights, and ambient bounce must match the declared scene location (e.g. Aswan Golden Hour vs. Khan el-Khalili warm lanterns).
4. **Separation of Face and Wardrobe**: Never allow wardrobe changes to mutate facial bone structure; enforce decoupled inpainting masks for apparel swaps.

## Standard Output Schema
```json
{
  "status": "success",
  "summary": "...",
  "confidence": 0.96,
  "risk_level": "low_visual_safety",
  "identity_metrics": {
    "reference_persona": "Persona_ID_Elena_UK",
    "face_similarity_cosine_score": 0.93,
    "total_scenes_rendered": 0,
    "passed_qa_ratio": "100%",
    "optical_profile": "35mm_f1.4_Leica_ColorScience"
  },
  "recommended_actions": [],
  "evidence": [],
  "assumptions": []
}
```

## Quality & Human-in-the-Loop Gate
- **Persona Approval Gate**: The master reference embedding is approved once by the Creative Director. All downstream scene renders passing the >= 0.88 biometric similarity score are automatically cleared for social and video asset pipelines.

## Executable Helper Script
The agent can programmatically trigger consistent character photo generation and biometric verification using:
```bash
python ./scripts/studio_director.py --action photo --persona "Elena_UK" --scene "Elena at Karnak Temple, Luxor at sunset" --lens "35mm f/1.4 Leica"
```

