"""
Brand Safety & Quality Assurance Gate for Media Production (M26 & M27)
Enforces biometric consistency checks, cost thresholds, and brand compliance before release.
"""

import json
import os
import time

class BrandSafetyGate:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), "media_config.json")
            
        with open(config_path, "r", encoding="utf-8") as f:
            self.config = json.load(f)
            
        self.output_dir = self.config.get("general", {}).get("output_directory", "./outputs/media_renders")
        os.makedirs(self.output_dir, exist_ok=True)
        self.min_similarity = self.config.get("comfyui", {}).get("face_similarity_threshold", 0.88)

    def evaluate_biometric_similarity(self, persona_id, face_similarity_score):
        """
        Evaluates whether a rendered face complies with the character consistency threshold (>= 0.88).
        """
        passed = face_similarity_score >= self.min_similarity
        assessment = {
            "persona_id": persona_id,
            "measured_similarity": face_similarity_score,
            "required_threshold": self.min_similarity,
            "decision": "PASSED" if passed else "REJECTED_FACE_DRIFT",
            "action": "Proceed to color grading" if passed else "Auto-reroll seed in ComfyUI",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
        }
        return passed, assessment

    def verify_campaign_spec(self, video_spec):
        """
        Validates aspect ratios, dynamic pricing injection, and compliance flags.
        """
        errors = []
        warnings = []
        
        # Check aspect ratio
        if video_spec.get("aspect_ratio") not in ["9:16", "16:9", "1:1"]:
            errors.append("Invalid aspect ratio. Must be 9:16 (Reels/Shorts), 16:9, or 1:1.")
            
        # Check price injection
        price = video_spec.get("injected_price_eur")
        if not price or price <= 0:
            warnings.append("No dynamic price injected; ensure campaign uses relative price anchor.")
            
        # Check hook duration
        hook_duration = video_spec.get("hook_duration_sec", 3.0)
        if hook_duration > 4.0:
            warnings.append("Hook duration exceeds 4 seconds; may reduce retention on Meta Reels.")
            
        is_clean = len(errors) == 0
        return {
            "approved_for_draft": is_clean,
            "errors": errors,
            "warnings": warnings,
            "watermark_required": True,
            "clean_4k_export_authorized": False  # requires human sign-off
        }

    def generate_review_dossier(self, render_job_id, assets_summary):
        """
        Creates an audit package for Creative Director sign-off.
        """
        dossier_path = os.path.join(self.output_dir, f"audit_dossier_{render_job_id}.json")
        package = {
            "audit_id": f"AUDIT_{int(time.time())}",
            "job_id": render_job_id,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "brand": self.config.get("general", {}).get("brand_name", "NileVista"),
            "status": "AWAITING_HUMAN_DIRECTOR_SIGNOFF",
            "assets": assets_summary,
            "governance_note": "Draft rendered at 720p with security watermark. Clean 4K export locked until approved."
        }
        with open(dossier_path, "w", encoding="utf-8") as f:
            json.dump(package, f, indent=2, ensure_ascii=False)
        return dossier_path

if __name__ == "__main__":
    gate = BrandSafetyGate()
    ok, bio = gate.evaluate_biometric_similarity("Elena_UK", 0.93)
    print("Biometric Gate Check (0.93):", bio["decision"])
    ok_fail, bio_fail = gate.evaluate_biometric_similarity("Elena_UK", 0.81)
    print("Biometric Gate Check (0.81):", bio_fail["decision"])
