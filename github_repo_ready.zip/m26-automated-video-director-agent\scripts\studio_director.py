"""
Unified Media Studio Orchestrator for Antigravity AI Agents (M26 & M27)
Provides a clean CLI interface that agents can execute autonomously to produce visual/audio assets.
"""

import argparse
import json
import os
import sys

# Ensure local imports work
sys.path.append(os.path.dirname(__file__))

from comfy_bridge import ComfyUIBridge
from cloud_media_bridge import CloudMediaBridge
from brand_safety_gate import BrandSafetyGate

def run_photo_job(persona, scene, lens="35mm f/1.4 Leica", similarity_check=0.93):
    comfy = ComfyUIBridge()
    gate = BrandSafetyGate()
    
    # 1. Evaluate biometric safety gate
    passed, bio_info = gate.evaluate_biometric_similarity(persona, similarity_check)
    if not passed:
        return {"status": "rejected", "reason": "Biometric drift detected", "details": bio_info}
        
    # 2. Dispatch to ComfyUI
    res = comfy.generate_consistent_character(persona, scene, lens)
    res["biometric_gate"] = bio_info
    return res

def run_video_job(script, voice="luxury_british", injected_price=890, aspect_ratio="9:16"):
    cloud = CloudMediaBridge()
    gate = BrandSafetyGate()
    
    # 1. Verify Video Spec
    spec = {
        "aspect_ratio": aspect_ratio,
        "injected_price_eur": injected_price,
        "hook_duration_sec": 3.0
    }
    spec_check = gate.verify_campaign_spec(spec)
    
    # 2. Generate Voiceover Track
    audio_job = cloud.generate_voiceover_script(script, voice)
    
    # 3. Dispatch Visual Render Job
    video_job = cloud.dispatch_cloud_video_render(
        prompt=f"Cinematic split screen: European cold winter vs Sunny Egyptian Nile Cruise, price {injected_price} EUR",
        style="cinematic_egypt",
        duration_sec=30
    )
    
    # 4. Generate Audit Dossier
    dossier = gate.generate_review_dossier("JOB_NVT_WINTER_REEL", {
        "script": script,
        "audio": audio_job,
        "visual_render": video_job,
        "spec_check": spec_check
    })
    
    return {
        "status": "success",
        "video_job": video_job,
        "audio_job": audio_job,
        "spec_compliance": spec_check,
        "audit_dossier": dossier,
        "message": "Video production components synthesized. Draft queued for human director sign-off."
    }

def main():
    parser = argparse.ArgumentParser(description="Antigravity Media Studio CLI")
    parser.add_argument("--action", choices=["photo", "video", "status"], required=True)
    parser.add_argument("--persona", default="Elena_UK")
    parser.add_argument("--scene", default="Luxor Temple at sunset")
    parser.add_argument("--lens", default="35mm f/1.4 Leica")
    parser.add_argument("--script", default="While Europe is freezing, experience sunny Aswan.")
    parser.add_argument("--price", type=float, default=890.0)
    parser.add_argument("--aspect_ratio", default="9:16")

    args = parser.parse_args()

    if args.action == "status":
        comfy = ComfyUIBridge()
        online, info = comfy.is_server_online()
        print(json.dumps({"comfyui_online": online, "server": comfy.server_address}, indent=2))
        
    elif args.action == "photo":
        res = run_photo_job(args.persona, args.scene, args.lens)
        print(json.dumps(res, indent=2, ensure_ascii=False))
        
    elif args.action == "video":
        res = run_video_job(args.script, injected_price=args.price, aspect_ratio=args.aspect_ratio)
        print(json.dumps(res, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
