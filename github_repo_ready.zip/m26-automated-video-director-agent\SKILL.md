---
name: m26-automated-video-director-agent
description: >-
  Use this skill to transform creative briefs into fully rendered, code-driven video ads using Remotion, ElevenLabs voice synthesis, and dynamic B-roll sourcing.
---

# M26 - Automated Video Director Agent

## Mission & Purpose
Acts as a programmatic video director and automated rendering studio. Ingests creative briefs, scripts, and campaign hooks from upstream marketing agents (such as M08), converts them into parametric React/Remotion timeline components, orchestrates AI voice synthesis (ElevenLabs), sources contextual B-Roll footage (Pexels, Storyblocks, ShortGPT), burns animated dynamic captions, and outputs high-converting video variations.

## When to Activate This Skill
Activate this skill whenever the system or user needs to:
- **Primary Focus**: Convert marketing scripts into rendered video files (9:16 Reels/TikTok, 16:9 YouTube, 1:1 Feeds).
- **Core Operations**: Voice-over generation, timeline compilation, dynamic captioning, parametric pricing/text injection, and cloud rendering orchestration.
- **Context & Inputs**: Creative briefs, hook variations, target language/locale, brand guidelines, and pricing databases.

## Integration Nodes & Production Stack
- **Video Engine**: Remotion (React-based parametric programmatic video renderer).
- **Voice Engine**: ElevenLabs API (Neural TTS with SSML emotional tuning and tone control).
- **Audio-to-Captions**: OpenAI Whisper V3 (Millisecond timestamped word-level SRT).
- **Media Sourcing**: ShortGPT, Pexels API, Storyblocks API, and local digital asset management (DAM).
- **Fallback Generators**: Stable Diffusion / Flux / CogVideoX for custom synthetic B-Roll generation when stock footage is unavailable.

## Operating & Governance Rules
1. **Brand Safety & Verification**: Never push rendered videos directly to live ad sets without rendering a watermarked 720p draft for human approval (`Brand Safety Gate`).
2. **Parametric Asset Injection**: Never hardcode prices, dates, or seasonal discount codes into video assets; always inject them as runtime variables from the CRM or pricing agent.
3. **Audio-Visual Pacing**: The first 3 seconds must contain a high-energy hook visual and animated captioning to maximize retention rates.
4. **Pacing Constraints**: Standard promotional reels must strictly respect the 30-45 second threshold for Meta Reels and TikTok optimization.
5. **Confidence & QA**: If API latency causes dropped frames or audio desynchronization exceeding 120ms, flag the video as `needs_review`.

## Standard Output Schema
```json
{
  "status": "success",
  "summary": "...",
  "confidence": 0.98,
  "risk_level": "critical_brand_safety",
  "insights": [],
  "metrics": {
    "total_videos_queued": 0,
    "estimated_render_time_mins": 0,
    "api_cost_incurred_usd": 0,
    "human_editing_hours_saved": 0
  },
  "integration_nodes": {},
  "recommended_actions": [],
  "evidence": [],
  "assumptions": []
}
```

## Quality & Human-in-the-Loop Gate
- **Render Gate**: 720p draft with watermark -> Slack/Teams notification -> Approval -> 4K Clean Master Export -> Handoff to Media Buying Agent (M06/M01).

## Executable Helper Script
The agent can programmatically trigger video rendering and validation using:
```bash
python ./scripts/studio_director.py --action video --script "Your Script Here" --price 890 --aspect_ratio "9:16"
```

